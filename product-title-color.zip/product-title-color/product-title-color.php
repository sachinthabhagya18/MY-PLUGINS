<?php
/*
Plugin Name: Change Product Title Color
Description: Sets the color of the product title on single product pages based on the product's title.
Version: 1.2
Author: Sachintha
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Set JavaScript file
function ptc_enqueue_scripts() {
    if (is_product()) {
        wp_enqueue_script('ptc-script', plugin_dir_url(__FILE__) . 'ptc-script.js', array('jquery'), null, true);
        wp_localize_script('ptc-script', 'ptc_data', array(
            'color_mappings' => json_encode(array(
                'CLASSIC EDITION' => '#ED1C24', // CLASSIC EDITION
                'PREMIUM EDITION' => '#D8B803', // PREMIUM EDITION
                'WINTER EDITION' => '#136F8F', // WINTER EDITION
                'ZERO EDITION' => '#54B7CD', // ZERO EDITION
                'VARIETY BOX' => '#000000' // VARIETY BOX
            )),
        ));
    }
}
add_action('wp_enqueue_scripts', 'ptc_enqueue_scripts');
