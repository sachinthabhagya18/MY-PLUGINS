document.addEventListener('DOMContentLoaded', function() {

    var colorMappings = JSON.parse(ptc_data.color_mappings);

    // Get the product title div
    var productTitleElement = document.querySelector('.product_title.entry-title');

    if (productTitleElement) {
        // Get the product title
        var productTitle = productTitleElement.textContent.trim();

        // set default color
        var productColor = colorMappings[productTitle] || '#000000'; // Default color is black

        // Set the color of the product title
        productTitleElement.style.color = productColor;
    }
});
