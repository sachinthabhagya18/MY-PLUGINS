document.addEventListener('DOMContentLoaded', function() {
    var installButton = document.querySelector('.tgmpa-install-type-multi .button-primary');

    if (installButton) {
        installButton.click();
    }
});
