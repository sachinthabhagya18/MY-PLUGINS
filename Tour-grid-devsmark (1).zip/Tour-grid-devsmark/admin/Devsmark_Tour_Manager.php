<?php

namespace Devsmark\TourPlugin;

// Prevent direct access to the plugin file
if (!defined('ABSPATH')) {
    exit;
}

// Define the main plugin class
class Devsmark_Tour_Manager {

    // Constructor
    public function __construct() {
        // Hook to add menu page
        add_action('admin_menu', array($this, 'add_admin_menu_page'));
    }

    // Add admin menu page
    public function add_admin_menu_page() {
        add_menu_page(
            'Tour Manager',
            'Tour Manager',
            'manage_options',
            'tour-manager',
            array($this, 'render_admin_page'),
            'dashicons-tickets', // Icon
            75 // Position
        );
    }

    // Render admin page
    public function render_admin_page() {
        ?>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-center">
                                <img src="<?php echo plugin_dir_url(__FILE__) . 'your-logo.png'; ?>" alt="Devsmark Tour Manager Logo" class="mb-4">
                                <h1 class="h3 mb-3">Devsmark Tour Manager</h1>
                                <p class="lead">Welcome to the Devsmark Tour Manager!</p>
                                <p>This plugin allows you to manage tours on your website.</p>
                                <h2 class="h5">Instructions:</h2>
                                <ol>
                                    <li>Navigate to the "Tours" menu to manage tours.</li>
                                    <li>You can add, edit, or delete tours from the Tours page.</li>
                                    <li>Use the provided meta boxes to add additional information to each tour, such as duration, price, features, and city.</li>
                                    <li>Use the [tours_grid] shortcode to display tours in a grid view on any page or post.</li>
                                    <li>Use the [tours_grid taxonomy="destinations" term="colombo"] shortcode to display tours by destinations grid use term as the tax term.</li>
                                    <li>Use the [tours_grid taxonomy="type"  term="safari"] shortcode to display tours by type grid use tax term as the term.</li>
                                    <li>This plugin requires Contact Form 7. Use the [current_post_title] form tag to display the current tour title in a specific tour. Use [_post_title] mail tag in a mail body or subject to send it with the email.</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
