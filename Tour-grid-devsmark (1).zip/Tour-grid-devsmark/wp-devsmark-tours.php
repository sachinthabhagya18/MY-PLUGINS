<?php
/*
 * Plugin Name: Devsmark Tour Manager
 * Plugin URI: https://devsmark.com/
 * Description: Manage tours on your website with ease using the Devsmark Tour Manager plugin.
 * Author: Umeindra
 * Version: 2.5
 * Requires at least: 6.3
 * Requires PHP: 8.0.30
 */

// Prevent direct access to the plugin file
if (!defined('ABSPATH')) {
    exit;
}


// Update checker in action
require (plugin_dir_path(__FILE__) .'plugin-update-checker/plugin-update-checker.php');
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://nycus.devsmark.com/TourPlug/plugin.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'unique-plugin-or-theme-slug'
);


// Enqueue scripts and styles
add_action('wp_enqueue_scripts', 'devsmark_enqueue_scripts');
function devsmark_enqueue_scripts() {
    // Enqueue Popper.js
    wp_enqueue_script('popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.10.2/umd/popper.min.js', array(), '2.10.2', true);

    // Enqueue Bootstrap 5 CSS
    wp_enqueue_style('bootstrap-css', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css');

    // Enqueue Bootstrap 5 JavaScript
    wp_enqueue_script('bootstrap-js', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.min.js', array('jquery', 'popper'), '5.3.0', true);

    // Enqueue plugin CSS
    wp_enqueue_style('devsmark-plugin-css', plugin_dir_url(__FILE__) . 'assets/css/styles.css');

    // Enqueue plugin JS
    wp_enqueue_script('devsmark-plugin-js', plugin_dir_url(__FILE__) . 'assets/js/scripts.js', array('jquery'), '1.0.0', true);
}

// Include PHP files
require_once(plugin_dir_path(__FILE__) . 'includes/Devsmark_Tour_Plugin_Post.php');
require_once(plugin_dir_path(__FILE__) . 'includes/Devsmark_Tour_Plugin_Tour_Meta_Boxes.php');
require_once(plugin_dir_path(__FILE__) . 'includes/Devsmark_Tour_Plugin_Tour_Grid.php');
require_once(plugin_dir_path(__FILE__) . 'includes/Devsmark_Current_Post_Title_cf7_Plugin.php');
require_once(plugin_dir_path(__FILE__) . 'includes/Devsmark_Tour_Plugin_Tour_Grid_Destination.php');
require_once(plugin_dir_path(__FILE__) . 'includes/Devsmark_Tour_Plugin_Tour_Grid_Type.php');

require_once(plugin_dir_path(__FILE__) . 'admin/Devsmark_Tour_Manager.php');



// Instantiate classes
new \Devsmark\TourPlugin\Devsmark_Tour_Plugin_Post();
new \Devsmark\TourPlugin\Devsmark_Tour_Plugin_Tour_Meta_Boxes();
new \Devsmark\TourPlugin\Devsmark_Tour_Plugin_Tour_Grid();
new \Devsmark\TourPlugin\Devsmark_Current_Post_Title_cf7_Plugin();
// new \Devsmark\TourPlugin\Devsmark_Tour_Plugin_Tour_Grid_Destination();
new \Devsmark\TourPlugin\Devsmark_Tour_Plugin_Tour_Grid_Type();

new \Devsmark\TourPlugin\Devsmark_Tour_Manager();

