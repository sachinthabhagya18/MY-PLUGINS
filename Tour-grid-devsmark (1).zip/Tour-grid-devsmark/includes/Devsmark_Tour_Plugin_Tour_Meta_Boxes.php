<?php
namespace Devsmark\TourPlugin;

class Devsmark_Tour_Plugin_Tour_Meta_Boxes
{

    // Constructor
    public function __construct()
    {
        // Hook to add meta boxes
        add_action('add_meta_boxes', array($this, 'add_custom_tours_meta_boxes'));

        // Hook to save meta box data with nonce verification
        add_action('save_post', array($this, 'save_custom_tours_meta'));
    }

    // Add meta boxes
    public function add_custom_tours_meta_boxes()
    {
        add_meta_box('tour_duration', 'Tour Duration', array($this, 'tour_duration_meta_box_callback'), 'tour', 'normal', 'default');
        add_meta_box('tour_price', 'Tour Price', array($this, 'tour_price_meta_box_callback'), 'tour', 'normal', 'default');
        add_meta_box('tour_features', 'Tour Features', array($this, 'tour_features_meta_box_callback'), 'tour', 'normal', 'default');
        add_meta_box('tour_city', 'Tour City', array($this, 'tour_city_meta_box_callback'), 'tour', 'normal', 'default');
    }

    // Duration Meta Box Callback
    public function tour_duration_meta_box_callback($post)
    {
        $duration = get_post_meta($post->ID, '_tour_duration', true);

        // Add nonce field
        wp_nonce_field(basename(__FILE__), 'tour_meta_box_nonce');

        echo '<input type="text" name="tour_duration" value="' . esc_attr($duration) . '" />';
    }

    // Price Meta Box Callback
    public function tour_price_meta_box_callback($post)
    {
        $price = get_post_meta($post->ID, '_tour_price', true);
        // Add nonce field
        wp_nonce_field(basename(__FILE__), 'tour_meta_box_nonce');
        echo '<input type="text" name="tour_price" value="' . esc_attr($price) . '" />';
    }

    // Features Meta Box Callback
    public function tour_features_meta_box_callback($post)
    {
        $features = get_post_meta($post->ID, '_tour_features', true);
        echo '<textarea name="tour_features">' . esc_html($features) . '</textarea>';
    }

    // City Meta Box Callback
    public function tour_city_meta_box_callback($post)
    {
        $city = get_post_meta($post->ID, '_tour_city', true);
        echo '<input type="text" name="tour_city" value="' . esc_attr($city) . '" />';
    }

    // Save meta box data with nonce verification
    public function save_custom_tours_meta($post_id)
    {
        // Verify nonce
        if (!isset($_POST['tour_meta_box_nonce']) || !wp_verify_nonce($_POST['tour_meta_box_nonce'], basename(__FILE__))) {
            return;
        }

        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Sanitize and save meta box data
        $fields = array('tour_duration', 'tour_price', 'tour_features', 'tour_city');

        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
    }
}
