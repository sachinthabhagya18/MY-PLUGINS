<?php
namespace Devsmark\TourPlugin;

use WP_Query; // Import WP_Query class

class Devsmark_Tour_Plugin_Tour_Grid_Type
{

    // Constructor
    public function __construct()
    {
        // Hook to add shortcode
        add_shortcode('tours_grid', array($this, 'tours_grid_shortcode'));
    }

    // Shortcode to display tours in a grid view [tours_grid] 
    public function tours_grid_shortcode($atts)
    {
        $atts = shortcode_atts(
            array(
                'posts_per_page' => 8,
                'taxonomy' => 'type', // Default taxonomy name
                'term' => '', // Default taxonomy term
            ), $atts);

        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

        $args = array(
            'post_type' => 'tour',
            'posts_per_page' => intval($atts['posts_per_page']),
            'paged' => $paged,
        );

        // Add taxonomy query if term is provided
        if (!empty($atts['term'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => $atts['taxonomy'],
                    'field' => 'slug',
                    'terms' => $atts['term'],
                ),
            );
        }

        $query = new WP_Query($args);

        $output = '<div class="container">';

        if ($query->have_posts()) {
            $output .= '<div class="row ">';
            while ($query->have_posts()) {
                $query->the_post();
                $duration = esc_html(get_post_meta(get_the_ID(), '_tour_duration', true));
                $price = esc_html(get_post_meta(get_the_ID(), '_tour_price', true));
                $features = esc_html(get_post_meta(get_the_ID(), '_tour_features', true));
                $city = esc_html(get_post_meta(get_the_ID(), '_tour_city', true));
                $excerpt = get_the_excerpt();
                $output .= '<div class="col-md-3 py-4">';
                $output .= '<div class="card text-center" >';
                 // Set a fixed height for the image
    $output .= '<img src="' . esc_url(get_the_post_thumbnail_url(get_the_ID(), 'medium')) . '" class="card-img-top" alt="' . esc_attr(get_the_title()) . '" style="height: 200px;">';
                $output .= '<div class="card-body">';
                $output .= '<h5 class="card-title dtm_tour_grid_title text-center text-capitalize text-dark"><a class="stretched-link text-decoration-none fs-4 text-dark" href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></h5>';
                $output .= '<p class="card-text  text-center mb-2"> ' . $duration . '</p>';
                $output .= '<div class="overflow-hidden" style="height: 11rem;"><p class="card-text"> ' . $excerpt . '</p></div>';
                $output .= '<div class="mt-auto"><a class="text-center stretched-link text-decoration-none fs-4 text-dark" href="' . esc_url(get_permalink()) . '">' . '<button class="button-17" role="button">Read More</button></a></div>';

                // $output .= '<p class="card-text">Price: ' . $price . '</p>';
                // $output .= '<p class="card-text">Features: ' . $features . '</p>';
                // $output .= '<p class="card-text">City: ' . $city . '</p>';
                $output .= '</div>'; // close card-body
                $output .= '</div>'; // close card
                $output .= '</div>'; // close column
            }
            $output .= '</div>'; // close row
            wp_reset_postdata();
            $output .= '<div class="pagination_jobs pt-5 "><nav aria-label="Page navigation example"><ul class="pagination pagination-md justify-content-end">';

            $pagination_args = array(
                'base' => esc_url(add_query_arg('paged', '%#%')),
                'format' => '',
                'current' => max(1, $paged),
                'total' => $query->max_num_pages,
                'prev_text' => __('<li class="page-item page-link ">&laquo Prev', 'textdomain'), // Previous link text
                'next_text' => __('<li class="page-item page-link">Next &raquo', 'textdomain'), // Next link text
                'before_page_number' => '<li class="page-item page-link">', // Markup before page number
                'after_page_number' => '</li>', // Markup after page number
                'prev_next' => true, // Disable Previous and Next arrows
            );
            
            $pagination_links = paginate_links($pagination_args);
            
            // Highlight active page
            $pagination_links = str_replace('current', 'active', $pagination_links);
            
            $output .= $pagination_links;
            $output .= '</ul></nav></div>'; // close pagination
        } else {
            $output .= 'No tours found.';
        }

        $output .= '</div>'; // close container

        return $output;
    }
}
