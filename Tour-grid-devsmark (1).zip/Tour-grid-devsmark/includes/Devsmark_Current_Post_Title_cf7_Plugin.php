<?php
namespace Devsmark\TourPlugin;

class Devsmark_Current_Post_Title_cf7_Plugin {
        // Constructor
    public function __construct() {
        // Hook to add shortcode
        add_shortcode('current_post_title', array($this, 'post_title_shortcode'));

        // Hook to filter Contact Form 7 form tag attributes
        add_filter('shortcode_atts_wpcf7', array($this, 'add_post_title_to_cf7_form'));
    }

    // Function to get the current post title
    public function get_current_post_title() {
        global $post;
        return isset($post) ? esc_html($post->post_title) : '';
    }

    // Shortcode to display the current post title
    public function post_title_shortcode() {
        return $this->get_current_post_title();
    }

    // Add the current post title to Contact Form 7 form tag
    public function add_post_title_to_cf7_form($atts) {
        // Get the current post title
        $post_title = $this->get_current_post_title();

        // Append the post title to the form tag
        if ($post_title && isset($atts['post_title_field'])) {
            $atts['post_title_field'] = $post_title;
        }

        return $atts;
    }
}
