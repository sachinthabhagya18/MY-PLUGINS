<?php
namespace Devsmark\TourPlugin;

class Devsmark_Tour_Plugin_Post
{
    // Constructor
    public function __construct()
    {

        // Register custom post type tour
        add_action('init', array($this, 'register_custom_post_type'));
        // Register custom tax destinations type
        add_action('init', array($this, 'destinations_taxonomy'));

        // Register custom tax type type
        add_action('init', array($this, 'type_taxonomy'));

    }


    // Register Custom Post Type
    public function register_custom_post_type()
    {
        $labels = array(
            'name' => __('Tours'),
            'singular_name' => __('Tour'),
            'menu_name' => __('Tours'),
            'add_new' => __('Add New'),
            'add_new_item' => __('Add New Tour'),
            'edit_item' => __('Edit Tour'),
            'new_item' => __('New Tour'),
            'view_item' => __('View Tour'),
            'search_items' => __('Search Tours'),
            'not_found' => __('No tours found'),
            'not_found_in_trash' => __('No tours found in Trash'),
            'parent_item_colon' => __('Parent Tour:'),
            'all_items' => __('All Tours'),
            'archives' => __('Tour Archives'),
            'insert_into_item' => __('Insert into tour'),
            'uploaded_to_this_item' => __('Uploaded to this tour'),
            'filter_items_list' => __('Filter tours list'),
            'items_list_navigation' => __('Tours list navigation'),
            'items_list' => __('Tours list')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'tour'),
            'capability_type' => 'post',
            // 'taxonomies' => array('category'), // Add 'category' taxonomy support
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => null,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        );

        // Register post type
        register_post_type('tour', $args);
    }


    // Register Custom Taxonomy
    // Register Custom Taxonomy
    function destinations_taxonomy()
    {

        $labels = array(
            'name' => _x('Destinations', 'Taxonomy General Name', 'text_domain'),
            'singular_name' => _x('Destination', 'Taxonomy Singular Name', 'text_domain'),
            'menu_name' => __('Destinations', 'text_domain'),
            'all_items' => __('All destinations', 'text_domain'),
            'parent_item' => __('Parent destination', 'text_domain'),
            'parent_item_colon' => __('Parent destination', 'text_domain'),
            'new_item_name' => __('New destination Name', 'text_domain'),
            'add_new_item' => __('Add New destination', 'text_domain'),
            'edit_item' => __('Edit destination', 'text_domain'),
            'update_item' => __('Update destination', 'text_domain'),
            'view_item' => __('View destination', 'text_domain'),
            'separate_items_with_commas' => __('Separate destinationa with commas', 'text_domain'),
            'add_or_remove_items' => __('Add or remove destinationa', 'text_domain'),
            'choose_from_most_used' => __('Choose from the most used', 'text_domain'),
            'popular_items' => __('Popular destinations', 'text_domain'),
            'search_items' => __('Search destinations', 'text_domain'),
            'not_found' => __('Not Found', 'text_domain'),
            'no_terms' => __('No destinations', 'text_domain'),
            'items_list' => __('destinations list', 'text_domain'),
            'items_list_navigation' => __('destinations list navigation', 'text_domain'),
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
            'public' => false,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_nav_menus' => true,
            'show_tagcloud' => true,
        );
        register_taxonomy('destinations', array('tour'), $args);

    }

    // Register Custom type Taxonomy
    function type_taxonomy()
    {

        $labels = array(
            'name' => _x('Types', 'Taxonomy General Name', 'text_domain'),
            'singular_name' => _x('Type', 'Taxonomy Singular Name', 'text_domain'),
            'menu_name' => __('Types', 'text_domain'),
            'all_items' => __('All types', 'text_domain'),
            'parent_item' => __('Parent type', 'text_domain'),
            'parent_item_colon' => __('Parent type', 'text_domain'),
            'new_item_name' => __('New type Name', 'text_domain'),
            'add_new_item' => __('Add New type', 'text_domain'),
            'edit_item' => __('Edit type', 'text_domain'),
            'update_item' => __('Update type', 'text_domain'),
            'view_item' => __('View type', 'text_domain'),
            'separate_items_with_commas' => __('Separate type with commas', 'text_domain'),
            'add_or_remove_items' => __('Add or remove type', 'text_domain'),
            'choose_from_most_used' => __('Choose from the most used', 'text_domain'),
            'popular_items' => __('Popular type', 'text_domain'),
            'search_items' => __('Search type', 'text_domain'),
            'not_found' => __('Not Found', 'text_domain'),
            'no_terms' => __('No type', 'text_domain'),
            'items_list' => __('types list', 'text_domain'),
            'items_list_navigation' => __('types list navigation', 'text_domain'),
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
            'public' => false,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_nav_menus' => true,
            'show_tagcloud' => true,
        );
        register_taxonomy('type', array('tour'), $args);

    }


}
