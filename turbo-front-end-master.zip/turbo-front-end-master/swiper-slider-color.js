document.addEventListener("DOMContentLoaded", function() {

    

    // Get the active slide number and image filename
    function getActiveSlideInfo() {
        var activeSlide = document.querySelector('#canslider .swiper-slide.swiper-slide-active .swiper-slide-image');
        if (!activeSlide) {
            console.log('No active slide or image found.');
            return null;
        }

        var imageUrl = activeSlide.getAttribute('src');
        var imageName = imageUrl.split('/').pop();
        return { imageName: imageName };
    }


    // Select the element to change color
    var itemTitle = document.querySelector('.itemtitleproductcolor .elementor-heading-title');
    if (!itemTitle) return;
    document.querySelector('#change-description-with-can .elementor-widget-container ').innerHTML = '<div class="can-change"><p>Caffeinated Drink This provided the ingredients for a beverage in a 250ml can with Soursop & Lime flavors. Medium Sugar (8g /100ml) with Shelf- Life – 24 months.</p><ul><li>❤️ MIXED FRUIT FLAVOR</li><li>❤️ VITAMIN C, B6, B12 NIACIN</li><li>💪 L-CARNITINE</li><li>🫚 GINSENG</li><li>🍋 NATURAL LIME JUICE</li><li>🍐 NATURAL SOURSOP JUICE</li><li>🍯 NATURAL CANE SUGAR</li></ul></div>';

    // Listen for slide change events and change color
    var swiperWrapper = document.querySelector('#canslider .swiper-wrapper');
    if (swiperWrapper) {
        swiperWrapper.addEventListener('transitionend', function() {
            var activeSlideInfo = getActiveSlideInfo();
            if (activeSlideInfo !== null) {
                switch (activeSlideInfo.imageName) {
                    case 'jpeg-optimizer_winter-596x1536.png':
                        itemTitle.style.color = '#136f8f';
                        document.querySelector('#change-description-with-can .elementor-widget-container ').innerHTML = '<div class="can-change"><p>Caffeinated Drink This provided the ingredients for a beverage in a 250ml can with cinnamon and pepper flavors. Medium Sugar (8g /100ml) with Shelf- Life – 24 months.</p><ul><li>❤️ VITAMIN C, B6, B12 NIACIN</li><li>❤️ B & C VITAMINS</li><li>💪 L-CARNITINE</li><li>🫚 GINSENG</li><li>🍯 NATURAL CANE SUGAR</li><li>⚗️ NATURAL COFFE EXTRACT</li><li>⚗️ NATURAL PEPPER EXTRACT</li><li>⚗️ NATURAL CINNAMON EXTRACT</li><li>🍋 NATURAL LIME JUICE</li><li>🍓 BERRY FLAVOR</li></ul></div>';

                        break;
                    case 'jpeg-optimizer_Premium-596x1536.png':
                        itemTitle.style.color = '#D8B803';
                        document.querySelector('#change-description-with-can .elementor-widget-container p').textContent = 'Huuuu';
                        document.querySelector('#change-description-with-can .elementor-widget-container ').innerHTML = '<div class="can-change"><p>Caffeinated Drink This provided the ingredients for a beverage in a 250ml can with mixed berry and vanilla flavors. Medium Sugar (8g/100ml) with Shelf- Life – 24 months.</p><ul><li>❤️ VITAMIN C, B6, B12 NIACIN</li><li>🍓 BERRY FLAVOR</li><li>🫛 VANILLA FLAVOR</li><li>💪 L-CARNITINE</li><li>🫚 GINSENG</li><li>🍯 NATURAL CANE SUGAR</li></ul></div>';

                        break;
                    case 'jpeg-optimizer_classic-596x1536.png':
                        itemTitle.style.color = '#ED1C24';
                        document.querySelector('#change-description-with-can .elementor-widget-container ').innerHTML = '<div class="can-change"><p>Caffeinated Drink This provided the ingredients for a beverage in a 250ml can with Soursop & Lime flavors. Medium Sugar (8g /100ml) with Shelf- Life – 24 months.</p><ul><li>❤️ MIXED FRUIT FLAVOR</li><li>❤️ VITAMIN C, B6, B12 NIACIN</li><li>💪 L-CARNITINE</li><li>🫚 GINSENG</li><li>🍋 NATURAL LIME JUICE</li><li>🍐 NATURAL SOURSOP JUICE</li><li>🍯 NATURAL CANE SUGAR</li></ul></div>';

                        break;
                    case 'jpeg-optimizer_zero-596x1536.png':
                        itemTitle.style.color = '#54b7cd';
                        document.querySelector('#change-description-with-can .elementor-widget-container ').innerHTML = '<div class="can-change"><p>Caffeinated Drink This provided the ingredients for a beverage in a 250ml can with mixed berry and vanilla flavors. No Sugar (0g /100ml) with Shelf- Life – 24 months.</p><ul><li>❤️ VITAMIN C, B6, B12 NIACIN</li><li>🍓 BERRY FLAVOR</li><li>🫛 VANILLA FLAVOR</li><li>💪 L-CARNITINE</li><li>🫚 GINSENG</li><li>🍯 NATURAL CANE SUGAR</li></ul></div>';

                        break;
                    default:
                        // Reset color if none of the specified filenames match
                        itemTitle.style.color = '';
                        break;
                }
            }
        });
    }


});


document.addEventListener('DOMContentLoaded', function() {

    var colorMappings = JSON.parse(ptc_data.color_mappings);

    // Get the product title div
    var productTitleElement = document.querySelector('.product_title.entry-title');

    if (productTitleElement) {
        // Get the product title
        var productTitle = productTitleElement.textContent.trim();

        // set default color
        var productColor = colorMappings[productTitle] || '#000000'; // Default color is black

        // Set the color of the product title
        productTitleElement.style.color = productColor;
    }
});
