<?php
/*
Plugin Name: Swiper Slider Color
Description: Changes the color of an element based on the currently active slide swiper js
Version: 1.6
Author: Umeindra
*/

// Security measure: Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


function swiper_slider_color_enqueue_scripts() {
    // Enqueue JavaScript file in the footer
    wp_enqueue_script('swiper-slider-color-script', plugin_dir_url(__FILE__) . 'swiper-slider-color.js', array('jquery'), '1.0', true);
    wp_enqueue_style( 'plugin-style', plugins_url( 'swiper-slider-color.css', __FILE__ ) );
}
add_action('wp_enqueue_scripts', 'swiper_slider_color_enqueue_scripts');

// Hook to enqueue the Font Awesome library
add_action('wp_enqueue_scripts', 'enqueue_font_awesome_style_turbo');

function enqueue_font_awesome_style_turbo() {
    // Enqueue Font Awesome CSS
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css', array(), '6.0.0-beta3');
}

// Set JavaScript file
function ptc_enqueue_scripts() {
    if (is_product()) {
        wp_enqueue_script('ptc-script', plugin_dir_url(__FILE__) . 'swiper-slider-color.js', array('jquery'), null, true);
        wp_localize_script('ptc-script', 'ptc_data', array(
            'color_mappings' => json_encode(array(
                'CLASSIC EDITION' => '#ED1C24', // CLASSIC EDITION
                'PREMIUM EDITION' => '#D8B803', // PREMIUM EDITION
                'WINTER EDITION' => '#136F8F', // WINTER EDITION
                'ZERO EDITION' => '#54B7CD', // ZERO EDITION
                'VARIETY BOX' => '#000000' // VARIETY BOX
            )),
        ));
    }
}
add_action('wp_enqueue_scripts', 'ptc_enqueue_scripts');
